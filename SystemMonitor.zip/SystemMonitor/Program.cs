﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Data.SQLite;
using System.Threading;


namespace SystemMonitor
{
    class PerformanceMonitor
    {
        static void Main(string[] args)
        {
            string dbPath = "Data Source=performance_data.db";

            // Create DB and Table if they don't exist
            using (var conn = new SQLiteConnection(dbPath))
            {
                conn.Open();
                string createTableQuery = @"
                CREATE TABLE IF NOT EXISTS PerformanceData (
                    Timestamp DATETIME,
                    CPUUsage REAL,
                    RAMUsage REAL,
                    DiskUsage REAL,
                    DiskSpace REAL
                );";
                using (var cmd = new SQLiteCommand(createTableQuery, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }

            while (true)
            {
                // Gather data
                float cpuUsage = GetCpuUsage();
                float ramUsage = GetRamUsage();
                (float diskUsage, float diskSpace) = GetDiskUsage();

                // Save to database
                using (var conn = new SQLiteConnection(dbPath))
                {
                    conn.Open();
                    string insertQuery = "INSERT INTO PerformanceData (Timestamp, CPUUsage, RAMUsage, DiskUsage, DiskSpace) VALUES (@Timestamp, @CPUUsage, @RAMUsage, @DiskUsage, @DiskSpace)";
                    using (var cmd = new SQLiteCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Timestamp", DateTime.Now);
                        cmd.Parameters.AddWithValue("@CPUUsage", cpuUsage);
                        cmd.Parameters.AddWithValue("@RAMUsage", ramUsage);
                        cmd.Parameters.AddWithValue("@DiskUsage", diskUsage);
                        cmd.Parameters.AddWithValue("@DiskSpace", diskSpace);
                        cmd.ExecuteNonQuery();
                    }
                }

                // Wait for a minute before gathering data again
                Thread.Sleep(60000);
            }
        }

        static float GetCpuUsage()
        {
            var cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            cpuCounter.NextValue();
            Thread.Sleep(1000);  // Give time for counter to get accurate data
            return cpuCounter.NextValue();
        }

        static float GetRamUsage()
        {
            var ramCounter = new PerformanceCounter("Memory", "Available MBytes");
            float availableRam = ramCounter.NextValue();
            float totalRam = new Microsoft.VisualBasic.Devices.ComputerInfo().TotalPhysicalMemory / (1024 * 1024); // Convert to MB
            return (1 - (availableRam / totalRam)) * 100;
        }

        static (float, float) GetDiskUsage()
        {
            DriveInfo drive = DriveInfo.GetDrives().First(d => d.IsReady && d.DriveType == DriveType.Fixed);
            float totalSpace = drive.TotalSize / (1024 * 1024 * 1024);  // Convert to GB
            float usedSpace = totalSpace - (drive.TotalFreeSpace / (1024 * 1024 * 1024));  // Convert to GB
            return ((usedSpace / totalSpace) * 100, totalSpace);
        }
    }

}