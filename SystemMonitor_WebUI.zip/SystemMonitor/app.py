from flask import Flask, render_template, request, jsonify
import sqlite3
import pandas as pd
import sys
import os

app = Flask(__name__)

def get_performance_data(start_date=None, end_date=None):
    conn = sqlite3.connect('performance_data.db')
    query = "SELECT * FROM PerformanceData"
    
    if start_date and end_date:
        query += f" WHERE Timestamp BETWEEN '{start_date}' AND '{end_date}'"
    
    df = pd.read_sql(query, conn)
    conn.close()
    return df

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/data', methods=['GET'])
def data():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    db_file = request.args.get('db')

    # 連接選定的 .db 檔案
    conn = sqlite3.connect(f'./databases/{db_file}')
    cursor = conn.cursor()

    # 你的查詢邏輯
    query = f"SELECT Timestamp, CPUUsage, RAMUsage, DiskUsage FROM PerformanceData WHERE Timestamp BETWEEN ? AND ?"
    cursor.execute(query, (start_date, end_date))
    rows = cursor.fetchall()

    timestamps = [row[0] for row in rows]
    cpu_usage = [row[1] for row in rows]
    ram_usage = [row[2] for row in rows]
    disk_usage = [row[3] for row in rows]

    conn.close()

    return jsonify({
        'timestamps': timestamps,
        'cpu_usage': cpu_usage,
        'ram_usage': ram_usage,
        'disk_usage': disk_usage
    })

if __name__ == '__main__':
    sys.stdout = open(os.devnull, 'w')
    sys.stderr = open(os.devnull, 'w')
    app.run(host='0.0.0.0', debug=False, port=55120)
