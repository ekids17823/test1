#define TEST_DATA_DIRECTORY "D:/bld/nlohmann_json_1723651555814/work/json_test_data"
