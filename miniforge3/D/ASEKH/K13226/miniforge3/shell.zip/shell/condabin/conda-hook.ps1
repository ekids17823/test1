$Env:CONDA_EXE = "D:/ASEKH/K13226/miniforge3\Scripts\conda.exe"
$Env:_CE_M = $null
$Env:_CE_CONDA = $null
$Env:_CONDA_ROOT = "D:/ASEKH/K13226/miniforge3"
$Env:_CONDA_EXE = "D:/ASEKH/K13226/miniforge3\Scripts\conda.exe"
$CondaModuleArgs = @{ChangePs1 = $True}
Import-Module "$Env:_CONDA_ROOT\shell\condabin\Conda.psm1" -ArgumentList $CondaModuleArgs

Remove-Variable CondaModuleArgs